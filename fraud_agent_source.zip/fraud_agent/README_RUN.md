# Reply Mirror - Fraud Detection Agent

## Setup
```bash
python3 -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Run on a dataset
```bash
# Extract the zip, find Transactions.csv, then:
python main.py path/to/Transactions.csv output/truman_output.txt
```

## Submit
1. Upload the output .txt file to the challenge page
2. Enter the Session ID printed at the end as the Langfuse session ID
3. Upload this folder as source code .zip

## File structure expected in each dataset zip:
- Transactions.csv  ← required
- Users.csv         ← optional (used if present)
- Conversations.csv ← optional
- Messages.csv      ← optional
- Locations.csv     ← optional
